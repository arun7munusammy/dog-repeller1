package com.example.dogrepeller

import android.media.*
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*

class MainActivity : ComponentActivity() {
    private var tonePlayer: TonePlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tonePlayer = TonePlayer()

        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppScreen(
                        start = { f, v, pulse -> tonePlayer?.start(frequencyHz = f, volume = v, pulseMode = pulse) },
                        stop = { tonePlayer?.stop() }
                    )
                }
            }
        }
    }

    override fun onPause() {
        super.onPause()
        tonePlayer?.stop()
    }

    override fun onDestroy() {
        super.onDestroy()
        tonePlayer?.release()
    }
}

@Composable
fun AppScreen(
    start: (Float, Float, Boolean) -> Unit,
    stop: () -> Unit
) {
    var isPlaying by remember { mutableStateOf(false) }
    var freqKHz by remember { mutableFloatStateOf(18f) } // default 18 kHz
    var volume by remember { mutableFloatStateOf(0.7f) }
    var pulse by remember { mutableStateOf(true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Dog Repeller", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("Phones vary. Many cannot emit >20 kHz. Use cautiously and briefly.")

        Text("Frequency: ${'$'}{String.format("%.1f", freqKHz)} kHz")
        Slider(
            value = freqKHz,
            onValueChange = { freqKHz = it },
            valueRange = 10f..22f,
            steps = 12,
            modifier = Modifier.fillMaxWidth()
        )

        Text("Volume: ${'$'}{String.format("%.0f", volume * 100)}%")
        Slider(
            value = volume,
            onValueChange = { volume = it },
            valueRange = 0.1f..1f,
            steps = 0,
            modifier = Modifier.fillMaxWidth()
        )

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Checkbox(checked = pulse, onCheckedChange = { pulse = it })
            Text("Pulse mode (on/off bursts)")
        }

        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Button(
                enabled = !isPlaying,
                onClick = {
                    isPlaying = true
                    start(freqKHz * 1000f, volume, pulse)
                }
            ) { Text("Start") }

            OutlinedButton(
                enabled = isPlaying,
                onClick = {
                    isPlaying = false
                    stop()
                }
            ) { Text("Stop") }
        }

        Divider()

        Text(
            "Safety tips: keep volume modest, avoid continuous use, don't point at ears, and respect local rules.",
            fontSize = 12.sp
        )
    }
}

class TonePlayer {
    private var track: AudioTrack? = null
    private var job: Job? = null
    private val sampleRate = 48000
    private val bufferSize = AudioTrack.getMinBufferSize(
        sampleRate,
        AudioFormat.CHANNEL_OUT_MONO,
        AudioFormat.ENCODING_PCM_16BIT
    )

    fun start(frequencyHz: Float, volume: Float, pulseMode: Boolean) {
        stop()

        track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setBufferSizeInBytes(maxOf(bufferSize, sampleRate / 2))
            .build()

        track?.play()

        job = CoroutineScope(Dispatchers.Default).launch {
            val twoPi = (2.0 * Math.PI).toFloat()
            var phase = 0f
            val amp = (Short.MAX_VALUE * volume).toInt().coerceIn(1, Short.MAX_VALUE.toInt())
            val chunk = ShortArray(sampleRate / 10) // 100ms chunk
            val omega = twoPi * (frequencyHz / sampleRate)

            var pulseOn = true
            var counter = 0
            val chunksPerPulseWindow = 2 // 200ms on/off

            while (isActive && track?.playState == AudioTrack.PLAYSTATE_PLAYING) {
                for (i in chunk.indices) {
                    val value = if (pulseMode && !pulseOn) 0f else kotlin.math.sin(phase)
                    chunk[i] = (amp * value).toInt().toShort()
                    phase += omega
                    if (phase > twoPi) phase -= twoPi
                }
                track?.write(chunk, 0, chunk.size)

                if (pulseMode) {
                    counter++
                    if (counter % chunksPerPulseWindow == 0) {
                        pulseOn = !pulseOn
                    }
                }
            }
        }
    }

    fun stop() {
        job?.cancel()
        job = null
        track?.let {
            try {
                it.stop()
            } catch (_: Throwable) {}
            it.release()
        }
        track = null
    }

    fun release() {
        stop()
    }
}
