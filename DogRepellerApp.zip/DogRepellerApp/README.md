# Dog Repeller (Android, Kotlin + Compose)

This app plays a high-frequency tone (10–22 kHz) intended to deter dogs. **Use briefly and humanely.**
Many phone speakers cannot reproduce true ultrasonic frequencies (>20 kHz); effectiveness varies by device and environment.

## Build & Run (Android Studio)
1. Open Android Studio (Giraffe+/latest) and choose **Open**.
2. Select the `DogRepellerApp` folder.
3. Let Gradle sync complete (Android Studio will install the right Gradle wrapper automatically).
4. Connect a device or start an emulator.
5. Click **Run** ▶ to install a debug build.
6. To create an APK: `Build` → `Build Bundle(s) / APK(s)` → `Build APK(s)`.

## Features
- Adjustable frequency slider (10–22 kHz).
- Volume control.
- Optional pulse mode (200ms on/off bursts).
- Big Start/Stop controls.
- Auto-stops when the app goes to background.

## Notes & Safety
- Keep volume moderate; avoid pointing the speaker at ears at close range.
- Avoid prolonged continuous playback.
- Respect local laws or regulations regarding ultrasonic deterrents.
- Try 15–18 kHz first; many phones drop off above ~16–19 kHz.

## Troubleshooting
- **No sound?** Some speakers filter very high frequencies. Try 14–18 kHz, increase volume, or use an external speaker.
- **Stutters?** Lower frequency slightly; background CPU load may affect real-time generation.
- **App closes sound on background:** This is intended to prevent misuse.

## License
MIT
